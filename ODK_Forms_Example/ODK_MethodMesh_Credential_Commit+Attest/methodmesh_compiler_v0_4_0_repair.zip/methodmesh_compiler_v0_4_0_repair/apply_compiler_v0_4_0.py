#!/usr/bin/env python3
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import sys

FILES = [
    "pyproject.toml",
    "requirements.txt",
    "README.md",
    "CHANGELOG.md",
    "CHANGE_SUMMARY.md",
    "compile_form.command",
    "install.command",
]
DIRS = ["methodmesh_xlsform", "tests"]

def fail(msg: str) -> None:
    raise SystemExit(f"ERROR: {msg}")

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("compiler_root")
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()
    root = Path(args.compiler_root).expanduser().resolve()
    payload = Path(__file__).resolve().parent / "payload"

    for needed in [root / "methodmesh_xlsform" / "compiler.py", root / "tests" / "test_compile.py"]:
        if not needed.exists():
            fail(f"target does not look like a MethodMesh XLSForm compiler: missing {needed}")
    for needed in [payload / "methodmesh_xlsform" / "compiler.py", payload / "tests" / "test_compile.py"]:
        if not needed.exists():
            fail(f"repair payload incomplete: missing {needed}")

    print("Compiler v0.4.0 repair validation passed.")
    for d in DIRS:
        print(f"WOULD REPLACE {d}/")
    for f in FILES:
        print(f"WOULD REPLACE {f}")
    print("PRESERVE .venv/, examples/, methodmesh_build/, and generated release bundles")

    if args.check:
        print("No files were changed (--check).")
        return

    for d in DIRS:
        dst = root / d
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(payload / d, dst)
    for f in FILES:
        shutil.copy2(payload / f, root / f)
    print("MethodMesh XLSForm compiler v0.4.0 repair applied.")

if __name__ == "__main__":
    main()
